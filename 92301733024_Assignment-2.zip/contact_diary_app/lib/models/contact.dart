class Contact {
  final String name;
  final String mobileNumber;
  final String email;

  Contact(
      {required this.name, required this.mobileNumber, required this.email});
}
